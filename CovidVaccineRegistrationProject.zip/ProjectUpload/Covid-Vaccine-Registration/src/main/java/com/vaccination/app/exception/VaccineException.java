package com.vaccination.app.exception;

public class VaccineException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VaccineException(String msg) {
		super(msg);
	}
}
