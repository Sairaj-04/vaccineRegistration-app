package com.vaccination.app.Entity;

public enum Availability {

	AVAILABLE,
    NOT_AVAILABLE
}
